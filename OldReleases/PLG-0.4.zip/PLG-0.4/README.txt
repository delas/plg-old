                                                             Padova, 04 jun 2010

                 - - - - - - - - - - - - - - - - - - - - - - -
                  P R O C E S S    L O G    G E N E R A T O R
                 - - - - - - - - - - - - - - - - - - - - - - -

README FILE
===========

PACKAGE REQUIREMENT

In order to run this software, some used libraries need Graphvix Dot to be
installed in the computer. See http://www.graphviz.org/Download.php for more
info.


PACKAGE CONTENT

In this package there are the software binary files (in "bin" directory) and the
ProcessLogGenerator library (in "PLGLib" directory) that you can use to build
your own process constructor.


RUN THE SOFTWARE

To run the ProcessLogGenerator, there are many options:
  1. open a terminal and cd where the ProcessLogGenerator.jar file is, then run
       java -jar ProcessLogGenerator.jar
  2. right click the ProcessLogGenerator.jar file and click on "Open with Sun
     Java X Runtime" (where X is your Java distribution number)

