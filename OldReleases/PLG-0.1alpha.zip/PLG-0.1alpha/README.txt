README FILE
===========

PACKAGE REQUITEMENT

In order to run thin software, some used libraries need Graphvix Dot to be
installed in the computer. See http://www.graphviz.org/Download.php for more
info.


PACKAGE CONTENT

In this package there are the software binary files (in bin/ directory) and the
ProcessLogGenerator library (in PLGCore/ directory) that you can use to build
your own process constructor.


RUN THE SOFTWARE

To run the ProcessLogGenerator, there are many options:
  1. open a terminal and cd where the ProcessLogGenerator.jar file is, then run
       java -jar ProcessLogGenerator.jar
  2. right click the ProcessLogGenerator.jar file and click on "Open with Sun
     Java X Runtime" (where X is your Java distribution number)
